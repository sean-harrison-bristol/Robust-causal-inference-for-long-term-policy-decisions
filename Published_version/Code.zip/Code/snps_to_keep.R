#Folder paths
snp_path = ""
file_path = ""
data_path = ""

#Write .do code to keep SNPs for each trait for MR data

#Load in harmonised data
exposure_dat_harmonised = read.csv(paste(snp_path,"\\exposure_dat_harmonised_bmi.csv",sep=""))
traits = unique(exposure_dat_harmonised$trait[exposure_dat_harmonised$included == 1])
file = paste(file_path,"\\snps_to_keep.do",sep="")
write("**Do file to keep SNPs for each exposure",file,append=FALSE)
write(paste('cd ',data_path,sep=""),file,append=TRUE)
for(t in traits) {
  snps = as.character(unique(exposure_dat_harmonised$SNP[exposure_dat_harmonised$trait == t & exposure_dat_harmonised$included == 1]))
  write(paste("*Trait = ",t,sep=""),file,append=TRUE)
  write('use "snp_ipd.dta", clear',file,append=TRUE)
  write(" ",file,append=TRUE)
  snps_line = "keep id_ieu "
  for(s in snps){
    snps_line = paste(snps_line,s,"_ ",sep="")
  }
  write(snps_line,file,append=TRUE)
  write(paste('save "snps\\snps_',t,'.dta", replace',sep=""),file,append=TRUE)
  write('merge 1:1 id_ieu using "snps\\outcomes.dta", nogen',file,append=TRUE)
  
  write('gen snp = ""
        gen effect_allele = ""
        gen eaf = .
        gen outcome = ""
        gen beta = .
        gen se = .
        gen p = .
        gen cases = .
        gen controls = .
        gen n_total = .
        local i = 1
        local outcomes1 = "qaly_2015_both qaly_2017_both qaly_cost_2015_30k_both qaly_cost_2015_20k_both qaly_cost_2015_10k_both"
        local outcomes2 = "qaly_2015_primary qaly_2017_primary qaly_cost_2015_30k_primary qaly_cost_2015_20k_primary qaly_cost_2015_10k_primary"
        local outcomes3 = "qaly_2015_hes qaly_2017_hes qaly_cost_2015_30k_hes qaly_cost_2015_20k_hes qaly_cost_2015_10k_hes"
        local outcomes4 = "d4* cost_2015"
        local outcomes = "`outcomes1\' `outcomes2\' `outcomes3\' `outcomes4\'"
        foreach outcome of varlist `outcomes\' {
          qui regress `outcome\' rs* age sex pc* i.centre primary_care
          foreach snp of varlist rs* {
            local snpx = substr("`snp\'",1,length("`snp\'")-2)
            qui replace snp = "`snpx\'" in `i\'  
            qui replace outcome = "`outcome\'" in `i\'
            qui replace beta = _b[`snp\'] if snp == "`snpx\'" & outcome == "`outcome\'"
            qui replace se = _se[`snp\'] if snp == "`snpx\'" & outcome == "`outcome\'"
            qui sum `snp\'  
            qui replace eaf = r(mean)/2 if snp == "`snpx\'"  
            local effect_allele = upper(substr("`snp\'",length("`snp\'"),1))
            qui replace effect_allele = "`effect_allele\'" if snp == "`snpx\'" 
            local i = `i\'+1
          }
        }
        
        *Ns
        foreach outcome of varlist `outcomes\' {
          qui sum `outcome\'
          qui replace n_total = r(N) if outcome == "`out\'"
        }
        
        keep snp-n_total
        keep if snp != ""
        qui replace p = 2*normal(-abs(beta/se))',file,append=TRUE)
  write(paste('save "snps\\results_',t,'.dta", replace',sep=""),file,append=TRUE)
  
  write("",file,append=TRUE)
        }