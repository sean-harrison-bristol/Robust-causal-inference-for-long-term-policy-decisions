#Folder paths
wd_path = ""
data_path = ""

#Create MR graphs from main analysis
setwd(wd_path)

library(TwoSampleMR)
library(MRInstruments)
library(data.table)
library("ggplot2")
library(plyr); library(dplyr)

dat = read.csv("mr_analysis.csv",stringsAsFactors = FALSE)
dat = rename(dat,beta.outcome = beta_outcome, se.outcome = se_outcome,
             pval.outcome = pval_outcome, beta.exposure = beta_exposure,
             se.exposure = se_exposure, id.exposure = id_exposure, id.outcome = id_outcome)

dat$mr_keep = TRUE
dat$exposure = "BMI"

#MR plots
setwd(paste(wd_path,"/ivw",sep=""))
res <- mr(dat)
p1 <- mr_scatter_plot(res, dat)

x = res[res$method == "Inverse variance weighted" | res$method == "Wald ratio",c("outcome","exposure")]

for(i in 1:length(p1)){
  outcome = x$outcome[i]
  ggsave(p1[[i]], file=paste("IVW - ",outcome,".png",sep=""), width=7, height=7)
}

#Forest plots
res_single <- mr_singlesnp(dat)
p2 <- mr_forest_plot(res_single)

for(i in 1:length(p2)){
  outcome = x$outcome[i]
  outcome = gsub("/"," per ",outcome)
  ggsave(p2[[i]], file=paste("Forest plots - ",outcome,".png",sep=""), width=7, height=7)
}

#############################################################################

#Forest plots for ALL analyses
setwd(data_path)
#install.packages("forestplot")
library(forestplot)

master_data = read.csv("tables\\metan_r.csv",stringsAsFactors = FALSE)
master_data$effect = gsub("£","�",master_data$effect)
master_data$outcome = gsub("£","�",master_data$outcome)

#By Exposure
#Iterate through social/socioeconomic outcomes for all health conditions/risk factors
x_list = unique(master_data$outcome)

for(x in x_list){
  
  #Plot group 1
  data = master_data[master_data$outcome == x & !is.na(master_data$plot_group_1),]
  data = data[order(data$outcome,data$type),]
  tabletext = cbind(unique(data$label),(paste(data$effect[data$type=="Main Analysis MR"],"\n","\n", data$effect[data$type=="Multivariable Adjusted"],sep="")))

  height = 800
  width = 800
  xlab_size = 1.2
  xtick_size = 1
  label_size = 1.2
  hrzl_lines = list("1"=gpar(lty=1),"2"=gpar(lty=1),"3"=gpar(lty=2),"4"=gpar(lty=1),"5"=gpar(lty=2),
                    "6"=gpar(lty=2),"7"=gpar(lty=1),"8"=gpar(lty=2),"9"=gpar(lty=2),"10"=gpar(lty=2),"11"=gpar(lty=2))
  
  filename = paste("graphs\\forest\\figure 1\\",x,".png",sep="")
  png(file=filename, width = width, height = height) 

  group = median(data$group)
  
  if(group == 0){
    xlab = "Percentage change in QALYs for a unit increase in BMI"
  } else {
    xlab = "Change in cost for a unit increase in BMI (�)"
  }
  
  if(x == x_list[1]){
    xticks = c(0,10,20,30,40)
  } else if(x == x_list[2]) {
    xticks = c(0,50,100,150,200,250)
  } else if(x == x_list[3]) {
    xticks = c(0,100,200,300,400)
  } else if(x == x_list[4]) {
    xticks = c(0,100,200,300,400,500,600)
  } else if(x == x_list[5]) {
    xticks = c(-1.5,-1.25,-1,-0.75,-0.5,-0.25,0)
  } else if(x == x_list[6] | x == x_list[7]) {
    xticks = c(-0.5,-0.4,-0.3,-0.2,-0.1,0,0.1,0.2)
  } else if(x == x_list[8]) {
    xticks = c(-1,-0.75,-0.5,-0.25,0,0.25)
  } else if(x == x_list[9]) {
    xticks = c(-10,0,10,20,30,40,50,60)
  } else if(x == x_list[10]) {
    xticks = c(0,25,50,75,100)
  }
  
  forestplot(tabletext, 
             legend = c("Main Analysis MR","Multivariable Adjusted"),
             title = x,
             mean = cbind(data$beta[data$type == "Main Analysis MR"], data$beta[data$type == "Multivariable Adjusted"]),
             lower = cbind(data$lower[data$type == "Main Analysis MR"], data$lower[data$type == "Multivariable Adjusted"]),
             upper = cbind(data$upper[data$type == "Main Analysis MR"], data$upper[data$type == "Multivariable Adjusted"]),
             col=fpColors(box=c("blue", "darkred"),
                          zero=c("darkblue")),
             boxsize = 0.1,
             line.margin = 0.2,
             xticks = xticks,
             grid = TRUE,
             hrzl_lines=hrzl_lines,
             txt_gp = fpTxtGp(xlab=gpar(cex=xlab_size),
                              ticks = gpar(cex=xtick_size),
                              label = list(gpar(cex=label_size),gpar(cex=0.8))),
             xlab = xlab

             
  )
  dev.off() 
  
  #Plot group 2
  data = master_data[master_data$outcome == x & !is.na(master_data$plot_group_2),]
  data = data[order(data$outcome,data$type),]
  tabletext = cbind(c(NA,"<50 years",NA,NA,"50-54 years",NA,NA,"55-59 years",NA,NA,"60-64 years",NA,NA,"65+ years",NA),
                    data$label[data$type=="Main Analysis MR"],
                    paste(data$effect[data$type=="Main Analysis MR"],"\n", data$effect[data$type=="Multivariable Adjusted"],sep=""))
  
  height = 800
  width = 800
  xlab_size = 1.2
  xtick_size = 1
  label_size = 1.2
  hrzl_lines = list("1"=gpar(lty=1),"2"=gpar(lty=2),"3"=gpar(lty=2),"4"=gpar(lty=1),"5"=gpar(lty=2),
                    "6"=gpar(lty=2),"7"=gpar(lty=1),"8"=gpar(lty=2),"9"=gpar(lty=2),"10"=gpar(lty=1),
                    "11"=gpar(lty=2),"12"=gpar(lty=2),"13"=gpar(lty=1),"14"=gpar(lty=2),"15"=gpar(lty=2))
  
  filename = paste("graphs\\forest\\figure 2\\",x,".png",sep="")
  png(file=filename, width = width, height = height) 
  
  group = median(data$group)
  
  if(group == 0){
    xlab = "Percentage change in QALYs for a unit increase in BMI"
  } else {
    xlab = "Change in cost for a unit increase in BMI (�)"
  }
  
  if(x == x_list[1]){
    xticks = c(-20,-10,0,10,20,30,40,50)
  } else if(x == x_list[2]) {
    xticks = c(-100,-50,0,50,100,150,200,250,300)
  } else if(x == x_list[3]) {
    xticks = c(-100,0,100,200,300,400,500)
  } else if(x == x_list[4]) {
    xticks = c(-200,-100,0,100,200,300,400,500,600,700)
  } else if(x == x_list[5]) {
    xticks = c(-2,-1.5,-1,-0.5,0,0.5)
  } else if(x == x_list[6] | x == x_list[7]) {
    xticks = c(-0.75,-0.5,-0.25,0,0.25,0.5)
  } else if(x == x_list[8]) {
    xticks = c(-1.5,-1.25,-1,-0.75,-0.5,-0.25,0,0.25,0.5)
  } else if(x == x_list[9]) {
    xticks = c(-50,-25,0,25,50,75)
  } else if(x == x_list[10]) {
    xticks = c(-50,-25,0,25,50,75,100,125)
  }
  
  forestplot(tabletext, 
             legend = c("Main Analysis MR","Multivariable Adjusted"),
             title = x,
             mean = cbind(data$beta[data$type == "Main Analysis MR"], data$beta[data$type == "Multivariable Adjusted"]),
             lower = cbind(data$lower[data$type == "Main Analysis MR"], data$lower[data$type == "Multivariable Adjusted"]),
             upper = cbind(data$upper[data$type == "Main Analysis MR"], data$upper[data$type == "Multivariable Adjusted"]),
             col=fpColors(box=c("blue", "darkred"),
                          zero=c("darkblue")),
             boxsize = 0.1,
             line.margin = 0.2,
             xticks = xticks,
             grid = TRUE,
             hrzl_lines=hrzl_lines,
             txt_gp = fpTxtGp(xlab=gpar(cex=xlab_size),
                              ticks = gpar(cex=xtick_size),
                              label = list(gpar(cex=label_size),gpar(),gpar(cex=0.8))),
             xlab = xlab
             
             
  )
  dev.off() 

}  

#####################################################################################################################################